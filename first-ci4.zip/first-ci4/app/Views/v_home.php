<?= $this->extend('v_template') ?>

<?= $this->section('content') ?>

    <p>SELAMAT DATANG <?= $username ?></p>

<?= $this->endSection() ?>
<?= $this->extend('v_template') ?>

<?= $this->section('content') ?>

    <p>INFORMASI</p>

<?= $this->endSection() ?>